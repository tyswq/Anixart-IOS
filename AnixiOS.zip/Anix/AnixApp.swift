import AVFoundation
import SwiftUI

@main
struct AnixApp: App {
    @State private var auth = AuthStore()

    init() {
        // звук должен идти и при выключенном беззвучном режиме, и в фоне (картинка в картинке)
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
        try? AVAudioSession.sharedInstance().setActive(true)
        Task { await AnixAPI.toggles() }
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(auth)
                .tint(Theme.accent)
                .preferredColorScheme(.dark)
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            Tab("Главная", systemImage: "house.fill") { HomeView() }
            Tab("Закладки", systemImage: "bookmark.fill") { LibraryView() }
            Tab("Профиль", systemImage: "person.crop.circle.fill") { ProfileView() }
            Tab(role: .search) { SearchView() }
        }
        .modifier(MinimizingTabBar())
    }
}

/// iOS 26: панель вкладок сворачивается при прокрутке вниз.
private struct MinimizingTabBar: ViewModifier {
    func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.tabBarMinimizeBehavior(.onScrollDown)
        } else {
            content
        }
    }
}
