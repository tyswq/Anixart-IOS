import SwiftUI

private let listNames = ["Не смотрю", "Смотрю", "В планах", "Просмотрено", "Отложено", "Брошено"]

struct ReleaseView: View {
    @Environment(AuthStore.self) private var auth
    @State private var release: Release
    @State private var expanded = false
    @State private var showLogin = false
    @State private var loaded = false
    @State private var loadError: String?
    @State private var note: String?
    // что сервер знает на самом деле: кнопки отвечают сразу, а запросы уходят следом
    @State private var favServer: Bool?
    @State private var favTask: Task<Void, Never>?
    @State private var listServer: Int?
    @State private var listTask: Task<Void, Never>?

    init(release: Release) {
        _release = State(initialValue: release)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                if !loaded, let loadError {
                    ErrorState(message: loadError) { Task { await reload() } }
                }
                header
                actions
                stats
                description
                info
                genres
                NavigationLink(value: CommentsRoute(release: release)) {
                    HStack {
                        Image(systemName: "bubble.left.and.bubble.right.fill")
                        Text("Комментарии").font(.headline)
                        if let n = release.commentCount, n > 0 { Text("\(n)").foregroundStyle(.secondary) }
                        Spacer()
                        Image(systemName: "chevron.right").font(.footnote.weight(.bold)).foregroundStyle(.secondary)
                    }
                    .padding(16)
                    .glassCard(radius: 22, interactive: true)
                    .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 40)
        }
        .background { AmbientBackground(image: release.image) }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if let url = URL(string: "https://anixart.tv/release/\(release.id)") {
                    ShareLink(item: url)
                }
            }
        }
        .task { await reload() }
        .banner($note)
        .sheet(isPresented: $showLogin) { LoginView() }
    }

    // MARK: Блоки

    private var header: some View {
        HStack(alignment: .bottom, spacing: 16) {
            Poster(url: release.image, radius: 22)
                .frame(width: 132, height: 198)
                .shadow(color: .black.opacity(0.5), radius: 18, y: 10)
            VStack(alignment: .leading, spacing: 8) {
                Text(headerTitle).font(.title2.weight(.bold)).lineLimit(4)
                if let o = release.titleOriginal, release.titleRu != nil {
                    Text(o).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                }
                HStack(spacing: 6) {
                    if let c = release.category?.name { tag(c) }
                    if let s = release.status?.name { tag(s) }
                    if let a = release.ageText { tag(a) }
                }
                if let g = release.gradeText {
                    HStack(spacing: 6) {
                        Image(systemName: "star.fill").foregroundStyle(.yellow)
                        Text(g).font(.title3.weight(.bold))
                        if let v = release.voteCount {
                            Text("· \(v.formatted()) оценок").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            Spacer(minLength: 0)
        }
        .padding(.top, 8)
    }

    private var headerTitle: String {
        if release.titleRu == nil && release.titleOriginal == nil && !loaded { return L("Загрузка…") }
        return release.displayTitle
    }

    private func tag(_ s: String) -> some View {
        Text(s)
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10).padding(.vertical, 5)
            .glassBackground(Capsule())
    }

    private var currentStatus: Int { release.profileListStatus ?? 0 }

    private var actions: some View {
        GlassGroup(spacing: 12) {
            HStack(spacing: 12) {
                NavigationLink(value: WatchRoute(release: release)) {
                    Label(LocalizedStringKey(release.isAnnounce && (release.episodesReleased ?? 0) == 0 ? "Анонс" : "Смотреть"), systemImage: "play.fill")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .glassBackground(Capsule(), interactive: true, tint: Theme.accent)
                        .contentShape(Capsule())
                }
                .buttonStyle(.plain)

                Menu {
                    Picker("Список", selection: Binding(
                        get: { currentStatus },
                        set: { v in setList(v) }
                    )) {
                        ForEach(0..<listNames.count, id: \.self) { i in
                            Text(LocalizedStringKey(listNames[i])).tag(i)
                        }
                    }
                } label: {
                    Image(systemName: currentStatus == 0 ? "bookmark" : "bookmark.fill")
                        .font(.title3)
                        .frame(width: 54, height: 54)
                        .glassBackground(Circle(), interactive: true)
                }

                Button {
                    toggleFavorite()
                } label: {
                    Image(systemName: release.isFavorite == true ? "heart.fill" : "heart")
                        .font(.title3)
                        .foregroundStyle(release.isFavorite == true ? Theme.accent : Color.primary)
                        .frame(width: 54, height: 54)
                        .glassBackground(Circle(), interactive: true)
                }
                .buttonStyle(.plain)
                .sensoryFeedback(.impact, trigger: release.isFavorite)
                .animation(.spring(duration: 0.25), value: release.isFavorite)
            }
        }
    }

    @ViewBuilder
    private var stats: some View {
        let items: [(String, Int?)] = [
            ("Смотрят", release.watchingCount), ("В планах", release.planCount),
            ("Просмотрено", release.completedCount), ("Отложено", release.holdOnCount), ("Брошено", release.droppedCount),
        ]
        if items.contains(where: { ($0.1 ?? 0) > 0 }) {
            HStack(spacing: 0) {
                ForEach(items.indices, id: \.self) { i in
                    VStack(spacing: 3) {
                        Text((items[i].1 ?? 0).formatted(.number.notation(.compactName))).font(.headline.monospacedDigit())
                        Text(LocalizedStringKey(items[i].0)).font(.system(size: 10)).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.7)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .padding(.vertical, 14)
            .glassCard(radius: 22)
        }
    }

    @ViewBuilder
    private var description: some View {
        if let d = release.desc, !d.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Text(d)
                    .font(.callout)
                    .lineLimit(expanded ? nil : 5)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(LocalizedStringKey(expanded ? "Свернуть" : "Читать полностью"))
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(Theme.accent)
            }
            .padding(16)
            .glassCard(radius: 22)
            .onTapGesture { withAnimation(.smooth) { expanded.toggle() } }
        }
    }

    @ViewBuilder
    private var info: some View {
        let rows = infoRows
        if !rows.isEmpty {
            VStack(spacing: 0) {
                ForEach(rows.indices, id: \.self) { i in
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: rows[i].0).frame(width: 22).foregroundStyle(Theme.accent)
                        Text(rows[i].1).font(.subheadline).frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .padding(.vertical, 11)
                    if i < rows.count - 1 { Divider().opacity(0.4) }
                }
            }
            .padding(.horizontal, 16)
            .glassCard(radius: 22)
        }
    }

    private var infoRows: [(String, String)] {
        var rows: [(String, String)] = []
        let ep = [release.episodesText, release.duration.map { L("%ld мин.", $0) }].compactMap { $0 }.joined(separator: " · ")
        if !ep.isEmpty { rows.append(("film.stack", ep)) }
        let seasonYear = [release.seasonName, release.year.map { L("%ld г.", $0) }].compactMap { $0 }.joined(separator: " ")
        let when = [release.country, seasonYear].compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: ", ")
        if !when.isEmpty { rows.append(("calendar", when)) }
        if let s = release.studio, !s.isEmpty { rows.append(("building.2", L("Студия %@", s))) }
        if let s = release.source, !s.isEmpty { rows.append(("book.closed", L("Первоисточник: %@", s))) }
        if let s = release.translators, !s.isEmpty { rows.append(("mic", s)) }
        if let s = release.releaseDate, !s.isEmpty { rows.append(("clock", s)) }
        return rows
    }

    @ViewBuilder
    private var genres: some View {
        let list = release.genreList
        if !list.isEmpty {
            FlowLayout(spacing: 8) {
                ForEach(list, id: \.self) { g in
                    Text(g)
                        .font(.footnote.weight(.medium))
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .glassBackground(Capsule())
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    // MARK: Действия

    private func reload() async {
        for _ in 0..<2 {
            do {
                let full = try await AnixAPI.release(release.id)
                // пока уходят запросы на сервер, не затираем то, что пользователь уже нажал
                if favTask == nil && listTask == nil {
                    release = full
                    favServer = full.isFavorite == true
                    listServer = full.profileListStatus ?? 0
                }
                loaded = true
                loadError = nil
                return
            } catch {
                if Task.isCancelled { return }
                loadError = error.localizedDescription
                try? await Task.sleep(nanoseconds: 700_000_000)
            }
        }
    }

    /// Папка меняется на экране сразу, на сервер уходит последнее выбранное значение.
    private func setList(_ new: Int) {
        guard auth.isLoggedIn else { showLogin = true; return }
        if listServer == nil { listServer = currentStatus }
        guard new != currentStatus else { return }
        release.profileListStatus = new
        guard listTask == nil else { return }
        listTask = Task { await syncList() }
    }

    private func syncList() async {
        while let server = listServer, server != currentStatus {
            let want = currentStatus
            do {
                if want == 0 {
                    try await AnixAPI.listDelete(status: server, rid: release.id)
                } else {
                    try await AnixAPI.listAdd(status: want, rid: release.id)
                }
                listServer = want
            } catch {
                release.profileListStatus = server
                note = L("Не удалось изменить список")
                break
            }
        }
        listTask = nil
    }

    /// Сердечко меняется сразу, на сервер уходит последнее выбранное состояние.
    private func toggleFavorite() {
        guard auth.isLoggedIn else { showLogin = true; return }
        if favServer == nil { favServer = release.isFavorite == true }
        release.isFavorite = !(release.isFavorite == true)
        guard favTask == nil else { return }
        favTask = Task { await syncFavorite() }
    }

    private func syncFavorite() async {
        while let server = favServer, server != (release.isFavorite == true) {
            let want = release.isFavorite == true
            do {
                if want { try await AnixAPI.favAdd(release.id) } else { try await AnixAPI.favDelete(release.id) }
                favServer = want
            } catch {
                release.isFavorite = server
                note = L("Не удалось изменить избранное")
                break
            }
        }
        favTask = nil
    }
}

// MARK: - Комментарии

struct CommentsView: View {
    let release: Release

    init(release: Release) { self.release = release }

    @State private var items: [Comment] = []
    @State private var page = 0
    @State private var finished = false
    @State private var loading = false
    @State private var error: String?

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(items) { c in
                    row(c).onAppear { if c.id == items.last?.id { Task { await loadMore() } } }
                }
                if loading { ProgressView().padding() }
                if let error, items.isEmpty { ErrorState(message: error) { Task { await loadMore() } } }
                if items.isEmpty, finished, !loading {
                    EmptyState(icon: "bubble.left", title: "Комментариев пока нет")
                }
            }
            .padding(16)
        }
        .background { AmbientBackground(image: release.image) }
        .navigationTitle("Комментарии")
        .navigationBarTitleDisplayMode(.inline)
        .task { if items.isEmpty { await loadMore() } }
    }

    private func row(_ c: Comment) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Circle().fill(Color.primary.opacity(0.08))
                .overlay { RemoteImage(url: c.profile?.avatar) }
                .clipShape(Circle())
                .frame(width: 40, height: 40)
            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Text(c.profile?.login ?? L("Аноним")).font(.subheadline.weight(.semibold))
                    if let t = c.timestamp {
                        Text(Date(timeIntervalSince1970: t), format: .relative(presentation: .named))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    if let v = c.voteCount, v != 0 {
                        Label("\(v)", systemImage: "hand.thumbsup").font(.caption).foregroundStyle(.secondary)
                    }
                }
                if c.isDeleted == true {
                    Text("Комментарий удалён").font(.callout).foregroundStyle(.secondary)
                } else {
                    SpoilerText(text: c.message ?? "", isSpoiler: c.isSpoiler == true)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glassCard(radius: 22)
    }

    private func loadMore() async {
        guard !loading, !finished else { return }
        loading = true
        defer { loading = false }
        do {
            let res = try await AnixAPI.comments(releaseId: release.id, page: page)
            let known = Set(items.map(\.id))
            let fresh = res.filter { !known.contains($0.id) }
            if fresh.isEmpty { finished = true } else { items += fresh; page += 1 }
            error = nil
        } catch {
            if !Task.isCancelled { self.error = error.localizedDescription }
        }
    }
}

private struct SpoilerText: View {
    let text: String
    let isSpoiler: Bool

    init(text: String, isSpoiler: Bool) {
        self.text = text
        self.isSpoiler = isSpoiler
    }

    @State private var revealed = false

    var body: some View {
        Text(text)
            .font(.callout)
            .frame(maxWidth: .infinity, alignment: .leading)
            .blur(radius: isSpoiler && !revealed ? 7 : 0)
            .overlay {
                if isSpoiler && !revealed {
                    Text("Спойлер").font(.caption.weight(.bold)).padding(.horizontal, 10).padding(.vertical, 4).glassBackground(Capsule())
                }
            }
            .onTapGesture { withAnimation(.smooth) { revealed = true } }
    }
}
