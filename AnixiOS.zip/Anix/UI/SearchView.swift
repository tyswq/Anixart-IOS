import SwiftUI

struct SearchView: View {
    @State private var query = ""
    @State private var results: [Release] = []
    @State private var page = 0
    @State private var finished = false
    @State private var loading = false
    @State private var searched = false
    @State private var error: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 12) {
                    ForEach(results) { r in
                        ReleaseRow(release: r)
                            .onAppear { if r.id == results.last?.id { Task { await loadMore() } } }
                    }
                    if loading { ProgressView().padding() }
                    if let error, results.isEmpty {
                        ErrorState(message: error) { Task { await reset() } }
                    } else if results.isEmpty, !loading {
                        if searched {
                            EmptyState(icon: "magnifyingglass", title: "Ничего не нашли", subtitle: "Попробуйте другое название")
                        } else {
                            EmptyState(icon: "sparkle.magnifyingglass", title: "Поиск по каталогу", subtitle: "Введите название аниме")
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .scrollDismissesKeyboard(.immediately)
            .background { AmbientBackground() }
            .navigationTitle("Поиск")
            .searchable(text: $query, prompt: "Название аниме")
            .task(id: query) {
                // дебаунс: пока пользователь печатает, задача отменяется
                try? await Task.sleep(nanoseconds: 400_000_000)
                if Task.isCancelled { return }
                await reset()
            }
            .appDestinations()
        }
    }

    private func reset() async {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        page = 0
        finished = false
        error = nil
        results = []
        guard !q.isEmpty else {
            searched = false
            return
        }
        searched = true
        await loadMore()
    }

    private func loadMore() async {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty, !loading, !finished else { return }
        loading = true
        defer { loading = false }
        do {
            let res = try await AnixAPI.search(page: page, query: q)
            guard q == query.trimmingCharacters(in: .whitespacesAndNewlines) else { return }
            let known = Set(results.map(\.id))
            let fresh = res.filter { !known.contains($0.id) }
            if fresh.isEmpty { finished = true } else { results += fresh; page += 1 }
            error = nil
        } catch {
            if !Task.isCancelled { self.error = error.localizedDescription }
        }
    }
}
