import SwiftUI

enum Theme {
    static let accent = Color(red: 0.94, green: 0.31, blue: 0.36)
    static let background = Color(red: 0.04, green: 0.04, blue: 0.07)
}

// MARK: - Liquid Glass

@available(iOS 26.0, *)
private func makeGlass(interactive: Bool, tint: Color?) -> Glass {
    var g = Glass.regular
    if let tint { g = g.tint(tint) }
    if interactive { g = g.interactive() }
    return g
}

extension View {
    /// Liquid Glass на iOS 26+, на более старых системах — матовый материал.
    @ViewBuilder
    func glassBackground<S: Shape>(_ shape: S, interactive: Bool = false, tint: Color? = nil) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffect(makeGlass(interactive: interactive, tint: tint), in: shape)
        } else {
            self
                .background {
                    ZStack {
                        shape.fill(.ultraThinMaterial)
                        if let tint { shape.fill(tint.opacity(0.85)) }
                    }
                }
                .overlay { shape.stroke(Color.white.opacity(0.14), lineWidth: 0.5) }
        }
    }

    func glassCard(radius: CGFloat = 24, interactive: Bool = false, tint: Color? = nil) -> some View {
        glassBackground(RoundedRectangle(cornerRadius: radius, style: .continuous), interactive: interactive, tint: tint)
    }
}

/// Группа стеклянных элементов: на iOS 26 они «сливаются» друг с другом, как в системных панелях.
struct GlassGroup<Content: View>: View {
    var spacing: CGFloat = 12
    @ViewBuilder var content: () -> Content

    var body: some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: spacing) { content() }
        } else {
            content()
        }
    }
}

// MARK: - Фон

/// Тёмный фон с размытым постером: цвет страницы подхватывает картинку.
struct AmbientBackground: View {
    var image: String?

    var body: some View {
        ZStack {
            Theme.background
            RadialGradient(
                colors: [Theme.accent.opacity(0.28), .clear],
                center: .topTrailing, startRadius: 0, endRadius: 520
            )
            RadialGradient(
                colors: [Color.indigo.opacity(0.25), .clear],
                center: .bottomLeading, startRadius: 0, endRadius: 560
            )
            if let image, !image.isEmpty {
                Color.clear
                    .overlay { RemoteImage(url: image).blur(radius: 70).opacity(0.5) }
                    .clipped()
                LinearGradient(
                    colors: [.clear, Theme.background.opacity(0.85), Theme.background],
                    startPoint: .top, endPoint: .bottom
                )
            }
        }
        .ignoresSafeArea()
    }
}
