<div align="center">

# Anix for iOS

[Русский](README.md) · **English**

An unofficial **Anixart** client for iPhone, built with SwiftUI.

[![Build](https://github.com/tyswq/Anixart-IOS/actions/workflows/build.yml/badge.svg)](https://github.com/tyswq/Anixart-IOS/actions/workflows/build.yml)
[![Release](https://img.shields.io/github/v/release/tyswq/Anixart-IOS?style=flat-square&color=ef4f5c)](https://github.com/tyswq/Anixart-IOS/releases/latest)
[![License](https://img.shields.io/github/license/tyswq/Anixart-IOS?style=flat-square&color=22c55e)](LICENSE)
![iOS 18+](https://img.shields.io/badge/iOS-18%2B-black?style=flat-square)

[Download](https://github.com/tyswq/Anixart-IOS/releases/latest) ·
[Changelog](CHANGELOG.en.md) ([Русский](CHANGELOG.md)) ·
[Report a bug](https://github.com/tyswq/Anixart-IOS/issues/new/choose)

</div>

The client is based on [arigandores/anix](https://github.com/arigandores/anix): the same endpoints, request
signing and video parsers. It is not affiliated with or endorsed by the Anixart developers.

## Installation

The app is unsigned, so it is installed by sideloading. A Windows or Mac computer is needed only for the installation.

1. Download `Anix-<version>.ipa` from the [Releases](https://github.com/tyswq/Anixart-IOS/releases/latest) page.
2. Install [Sideloadly](https://sideloadly.io). On Windows you need iTunes and iCloud downloaded from Apple's website, not from the Microsoft Store.
3. Connect your iPhone with a cable and tap Trust on the iPhone.
4. Drag the `.ipa` into the Sideloadly window, enter your Apple ID and click **Start**.
5. Turn on Developer Mode: **Settings → Privacy & Security → Developer Mode**, then restart the iPhone.
6. Trust the profile: **Settings → General → VPN & Device Management** → your Apple ID → **Trust**.

Updating: install the new `.ipa` over the old one the same way; your login and data are kept.

> A free Apple ID signs the app for **7 days**, after that it has to be reinstalled. [AltStore](https://altstore.io) and
> [SideStore](https://sidestore.io) can renew the signature automatically. A paid developer account signs for a year.

The minimum system is iOS 18. On iOS 26 the interface uses Liquid Glass; on iOS 18–25 it uses a frosted material instead.

## Building it yourself

This is only for people with a Mac. `Anix.xcodeproj` is not stored in the repository: it is created on your computer by `xcodegen generate` from `project.yml`, so run that first and only then open the project.

```sh
brew install xcodegen
xcodegen generate     # creates Anix.xcodeproj
open Anix.xcodeproj
```

Choose your own signing team and run. Xcode 26 is required.

## Project structure

```
Anix/
  AnixApp.swift         entry point, root screen and tabs
  Core/                 API, models, request signing, login, settings, stores
  UI/                   screens: home, release, search, library, profile, comments, settings
  Player/               AVPlayer-based player and video source parsing
  Resources/en.lproj/   English localization (keys are the Russian source strings)
  Assets.xcassets/      icon and resources
project.yml             project description for XcodeGen
CHANGELOG.md            changelog (Russian); CHANGELOG.en.md is the English one
README.en.md            this file
```

The `.xcodeproj` is not stored in the repository; XcodeGen creates it (see "Building it yourself").

## FAQ

**Covers don't load.** Turn on **Settings → Alternative connection**. Images then go through a mirror,
which helps when your provider blocks some CDN addresses.

**The app stopped opening.** A week has passed and the free Apple ID signature expired. Reinstall the `.ipa`.

**Video from some source doesn't work.** Kodik and AniLibria play directly. The other sources
open in the built-in web player, and how well it works depends on the source itself.

**Part of the text is still in Russian in English mode.** The release description, genres and status are translated by
the built-in iOS translator. On first launch the system may offer to download a language pack. Comments and episode
names are not translated.

## License

The code is released under the [MIT](LICENSE) license, like the original project.
Anixart, its name, logo and content belong to their respective owners. The catalog, accounts and comments are provided
by the Anixart service, and the video by third-party sources.
